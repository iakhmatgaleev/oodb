package lab9.Entities;

import java.util.Date;
import javax.persistence.*;

@Entity
public class Director extends Human{
    
    @OneToOne
    private Project project;

    public Director(Project  project ,String fullName, Date birthDate, int salary) {
        super(fullName, birthDate, salary);
        this.project=project;
    }

    public Director() {
        super();
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }
    
}
