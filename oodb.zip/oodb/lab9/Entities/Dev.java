package lab9.Entities;

import java.util.Date;
import javax.persistence.*;

@Entity
public class Dev extends Human{
    
    @OneToOne
    private Computer computer;

    public Dev(Computer computer, String fullName, Date birthDate, int salary) {
        super(fullName, birthDate, salary);
        this.computer = computer;
    }

    public Dev() {
        super();
    }

    /**
     * @return the computer
     */
    public Computer getComputer() {
        return computer;
    }

    /**
     * @param computer the computer to set
     */
    public void setComputer(Computer computer) {
        this.computer = computer;
    }
    
}
