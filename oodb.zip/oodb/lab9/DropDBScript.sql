drop table if exists server,team,project,dev,director,human,computer,techquest,team_server,team_project,team_dev,team_director,dev_computer,project_techquest;

