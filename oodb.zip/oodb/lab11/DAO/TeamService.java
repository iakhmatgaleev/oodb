package lab11.DAO.Dev;

import com.example.EntityManagerTask10.Entities.Team;
import java.util.List;

public interface TeamService {
    
    Team save(Team team);
    void delete(Team team);
    void deleteById(Long id);
    Team findById(Long id);
    List<Team> findAll();
    
}
