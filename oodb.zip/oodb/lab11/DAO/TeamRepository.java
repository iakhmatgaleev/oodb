package lab11.DAO.Dev;

import com.example.EntityManagerTask10.Entities.Team;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeamRepository extends JpaRepository<Team, Long>{
    
}
